# FreteNow / Kit de marca 1.0

O manual PDF reúne identidade, posicionamento, tom de voz, logo, proteção, mínimos, cores, tipografia, acessibilidade e aplicações Web, iOS, Android, documentos e comunicação.

O logo foi aprovado por Leo em 30/10/2026. Os SVGs são uma reconstrução técnica fiel em contornos, com cores sólidas. O PNG aprovado foi preservado em original/. O wordmark não depende de uma fonte instalada; não o redigite.

## Escolha do arquivo

- logos/svg: matriz escalável para design, Web e impressão. Arquivos reversos para fundo escuro; monocromáticos para reprodução em uma cor.
- logos/png: versões de apoio com transparência; não usar imagem branca sobre fundo branco.
- icons: matrizes de marca e camadas de preparação. Arquivos PNG/SVG não são um projeto Xcode, pacote .icon ou aplicativo Android. O empacotamento nativo e a revisão no Icon Composer/launchers serão feitos durante a implementação.
- applications: exemplos visuais com dados fictícios. Não são aplicativos funcionais ou telas já publicadas. Referências mobile incluem moldura ilustrativa, sem representar um modelo específico de aparelho.
- fonts: fontes variáveis originais e suas licenças SIL OFL. Preservar as licenças ao redistribuir.
- guidelines: conteúdo editorial completo, fontes oficiais verificadas, geometria, tokens e registro de aprovação.
- source: scripts de construção do manual e exportação; são fontes de produção editorial, não código da plataforma.

## Site e plataforma

O portal e os aplicativos usam a linguagem azul. A aplicação institucional usa uma expressão escura, predominantemente monocromática, a partir da distinção apontada por Leo no site público linklane.ai. Essa referência é interna e não indica parceria ou endosso.

## Aprovação e edição

O logo está aprovado. A assinatura “Clareza para mover.” é uma proposta editorial opcional desta edição; não integra o desenho obrigatório do logo. Regras complementares foram elaboradas na v1.0 e devem orientar a revisão das aplicações finais. Não foi iniciada a implementação da plataforma.

## Reprodução dos materiais

Os scripts originais permanecem em docs/brand/work/ no projeto. Dependências editoriais: Python, reportlab, pypdf, Pillow e FontTools; Poppler para renderização. A organização do workspace e os caminhos de runtime devem ser ajustados em outro computador. SVG/PNG/PDF e as fontes originais são utilizáveis independentemente dos scripts.
